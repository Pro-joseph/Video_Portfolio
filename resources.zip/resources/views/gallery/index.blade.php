@extends('layouts.app')

@push('styles')
<style>
.animate-on-scroll {
    opacity: 0;
    transform: translateY(40px);
    transition: opacity 0.8s ease-out, transform 0.8s ease-out;
}

.animate-on-scroll.visible {
    opacity: 1;
    transform: translateY(0);
}

.gallery-card {
    background: #171717;
    border: 1px solid #262626;
    transition: all 0.4s ease;
}

.gallery-card:hover {
    transform: translateY(-8px);
    border-color: rgba(234, 88, 12, 0.3);
}
</style>
@endpush

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });
    document.querySelectorAll('.animate-on-scroll').forEach(el => observer.observe(el));
});
</script>
@endpush

@section('title', 'Client Gallery - FrameFlow')

@section('content')
<div class="pt-32 pb-20 px-6" style="background: #0a0a0a;">
    <div class="max-w-7xl mx-auto">
        <div class="text-center mb-16 animate-on-scroll">
            <div class="accent-line mx-auto"></div>
            <h1 class="text-5xl font-display text-white mb-4">Client Gallery</h1>
            <p class="text-gray-500 text-lg max-w-2xl mx-auto">Browse our portfolio of work organized by client</p>
        </div>

        @if($clients->count() > 0)
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            @foreach($clients as $client)
            <a href="{{ route('gallery.show', $client->slug) }}" class="group animate-on-scroll delay-{{ $loop->index * 100 }}">
                <div class="gallery-card relative overflow-hidden aspect-square">
                    @if($client->logo)
                        <img src="{{ $client->logo_url }}" alt="{{ $client->name }}" class="w-full h-full object-contain p-8 group-hover:scale-105 transition-transform duration-300">
                    @else
                        <div class="w-full h-full flex items-center justify-center" style="background: rgba(234, 88, 12, 0.1);">
                            <span class="text-4xl font-display" style="color: rgba(234, 88, 12, 0.4);">{{ strtoupper(substr($client->name, 0, 1)) }}</span>
                        </div>
                    @endif
                    <div class="absolute inset-0 flex items-center justify-center" style="background: rgba(234, 88, 12, 0.9); opacity: 0; group-hover:opacity-100; transition: opacity 0.3s ease;">
                        <div class="text-white text-center">
                            <p class="font-display text-lg">{{ $client->images_count }} images</p>
                            <p class="text-sm text-white/80">Click to view</p>
                        </div>
                    </div>
                </div>
                <h3 class="text-xl font-display text-white mt-4 text-center group-hover:text-white transition-colors" style="color: #ea580c;">{{ $client->name }}</h3>
                @if($client->description)
                    <p class="text-gray-500 text-sm text-center mt-1 line-clamp-2">{{ $client->description }}</p>
                @endif
            </a>
            @endforeach
        </div>
        @else
        <div class="text-center py-20">
            <p class="text-gray-500">No gallery clients yet. Add clients in the admin panel.</p>
        </div>
        @endif
    </div>
</div>
@endsection