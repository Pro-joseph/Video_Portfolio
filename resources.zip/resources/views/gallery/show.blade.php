@extends('layouts.app')

@push('styles')
<style>
.animate-on-scroll {
    opacity: 0;
    transform: translateY(40px);
    transition: opacity 0.8s ease-out, transform 0.8s ease-out;
}

.animate-on-scroll.visible {
    opacity: 1;
    transform: translateY(0);
}

.gallery-image {
    background: #171717;
    border: 1px solid #262626;
    transition: all 0.4s ease;
}

.gallery-image:hover {
    transform: scale(1.02);
    border-color: rgba(234, 88, 12, 0.3);
}
</style>
@endpush

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });
    document.querySelectorAll('.animate-on-scroll').forEach(el => observer.observe(el));
});
</script>
@endpush

@section('title', $client->name . ' Gallery - FrameFlow')

@section('content')
<div class="pt-32 pb-20 px-6" style="background: #0a0a0a;">
    <div class="max-w-7xl mx-auto">
        <div class="text-center mb-12 animate-on-scroll">
            @if($client->logo)
                <img src="{{ $client->logo_url }}" alt="{{ $client->name }}" class="h-24 mx-auto mb-6 object-contain">
            @endif
            <div class="accent-line mx-auto"></div>
            <h1 class="text-5xl font-display text-white mb-4">{{ $client->name }}</h1>
            @if($client->description)
                <p class="text-gray-500 text-lg max-w-2xl mx-auto">{{ $client->description }}</p>
            @endif
            <a href="{{ route('gallery') }}" class="btn-secondary mt-6">Back to Gallery</a>
        </div>

        @if($images->count() > 0)
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            @foreach($images as $image)
            <div class="gallery-image relative group aspect-square overflow-hidden cursor-pointer" onclick="openLightbox('{{ $image->image_url }}', '{{ $image->caption ?? '' }}')">
                <img src="{{ $image->image_url }}" alt="{{ $image->caption ?? $client->name }}" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300">
                @if($image->caption)
                <div class="absolute inset-0 flex items-center justify-center" style="background: rgba(0,0,0,0.7); opacity: 0; group-hover:opacity-100; transition: opacity 0.3s;">
                    <p class="text-white text-center p-4 text-sm">{{ $image->caption }}</p>
                </div>
                @endif
            </div>
            @endforeach
        </div>
        @else
        <div class="text-center py-20">
            <p class="text-gray-500">No images for this client yet.</p>
        </div>
        @endif
    </div>
</div>

<div id="lightbox" class="fixed inset-0 z-50 hidden items-center justify-center p-4" style="background: rgba(10, 10, 10, 0.95);" onclick="closeLightbox()">
    <button class="absolute top-4 right-4 text-white text-4xl hover:text-white z-10" style="color: #ea580c;" onclick="event.stopPropagation(); closeLightbox();">&times;</button>
    <img id="lightbox-img" src="" alt="" class="max-w-full max-h-[90vh] object-contain">
    <p id="lightbox-caption" class="text-white text-center mt-4"></p>
</div>

@push('scripts')
<script>
function openLightbox(src, caption) {
    document.getElementById('lightbox-img').src = src;
    document.getElementById('lightbox-caption').textContent = caption;
    document.getElementById('lightbox').classList.remove('hidden');
    document.getElementById('lightbox').classList.add('flex');
    document.body.style.overflow = 'hidden';
}

function closeLightbox() {
    document.getElementById('lightbox').classList.add('hidden');
    document.getElementById('lightbox').classList.remove('flex');
    document.body.style.overflow = 'auto';
}
</script>
@endpush
@endsection