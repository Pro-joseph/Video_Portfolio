@extends('layouts.app')

@push('styles')
<style>
.animate-on-scroll {
    opacity: 0;
    transform: translateY(40px);
    transition: opacity 0.8s ease-out, transform 0.8s ease-out;
}

.animate-on-scroll.visible {
    opacity: 1;
    transform: translateY(0);
}

.form-input {
    font-family: 'Outfit', sans-serif;
    background: #171717;
    border: 1px solid #262626;
    color: #fafafa;
    padding: 1rem;
    transition: all 0.3s ease;
}

.form-input:focus {
    outline: none;
    border-color: #ea580c;
    box-shadow: 0 0 0 3px rgba(234, 88, 12, 0.1);
}

.form-input::placeholder {
    color: #525252;
}

.form-input option {
    background: #171717;
    color: #fafafa;
}

.service-card {
    background: #171717;
    border: 1px solid #262626;
    padding: 1.5rem;
    transition: all 0.3s ease;
}

.service-card:hover {
    border-color: rgba(234, 88, 12, 0.3);
}
</style>
@endpush

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });
    document.querySelectorAll('.animate-on-scroll').forEach(el => observer.observe(el));
});
</script>
@endpush

@section('title', 'Contact - FrameFlow')

@section('content')
@php
$email = $siteSettings['contact']['contact_email'] ?? 'hello@frameflow.com';
$phone = $siteSettings['contact']['contact_phone'] ?? '+1 (555) 123-4567';
@endphp

<div class="pt-32 pb-20 px-6" style="background: #0a0a0a;">
    <div class="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-16">
        <div class="animate-on-scroll">
            <div class="accent-line"></div>
            <h1 class="text-5xl font-display text-white mb-4">Get in Touch</h1>
            <p class="text-gray-500 text-xl mb-10">Have a project in mind? Let's discuss how we can bring your vision to life.</p>

            @if(session('success'))
                <div class="mb-8 p-4 border" style="background: rgba(34, 197, 94, 0.1); border-color: #22c55e; color: #22c55e;">
                    Thank you! We'll get back to you soon.
                </div>
            @endif

            <form action="{{ route('contact.store') }}" method="POST" class="space-y-6">
                @csrf
                <div>
                    <label class="block text-sm font-medium text-gray-300 mb-2">Name *</label>
                    <input type="text" name="name" required class="form-input w-full" placeholder="Your name">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-300 mb-2">Email *</label>
                    <input type="email" name="email" required class="form-input w-full" placeholder="your@email.com">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-300 mb-2">Project Type</label>
                    <select name="category_id" class="form-input w-full">
                        <option value="">Select project type</option>
                        @foreach($categories as $cat)
                        <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-300 mb-2">Message *</label>
                    <textarea name="body" rows="6" required class="form-input w-full resize-none" placeholder="Tell us about your project..."></textarea>
                </div>
                <button type="submit" class="btn-primary w-full justify-center">Send Message</button>
            </form>

            <div class="mt-12 pt-8 border-t" style="border-color: #262626;">
                <div class="flex flex-col gap-3">
                    <a href="mailto:{{ $email }}" class="text-gray-500 hover:text-white transition-colors flex items-center gap-3">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                        {{ $email }}
                    </a>
                    <a href="tel:{{ $phone }}" class="text-gray-500 hover:text-white transition-colors flex items-center gap-3">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                        {{ $phone }}
                    </a>
                </div>
            </div>
        </div>

        <div class="animate-on-scroll delay-200">
            <h2 class="text-2xl font-display text-white mb-8">Our Services</h2>
            <div class="space-y-4">
                @forelse($packages as $pkg)
                    <div class="service-card">
                        <div class="flex justify-between items-start mb-3">
                            <h3 class="text-lg font-display text-white">{{ $pkg->name }}</h3>
                            @if($pkg->price)
                                <span class="font-display" style="color: #ea580c;">${{ number_format($pkg->price, 0) }}</span>
                            @endif
                        </div>
                        <p class="text-gray-500 text-sm mb-3">{{ $pkg->description }}</p>
                        @if($pkg->features)
                            <ul class="space-y-2">
                                @foreach(array_slice($pkg->features, 0, 3) as $feature)
                                    <li class="text-gray-500 text-sm flex items-center gap-2">
                                        <svg class="w-4 h-4 flex-shrink-0" style="color: #ea580c;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                                        {{ $feature }}
                                    </li>
                                @endforeach
                            </ul>
                        @endif
                    </div>
                @empty
                    <p class="text-gray-500">No services available.</p>
                @endforelse
            </div>
        </div>
    </div>
</div>
@endsection