@extends('layouts.app')

@push('styles')
<style>
.hero-section {
    position: relative;
    min-height: 100vh;
    display: flex;
    align-items: center;
    overflow: hidden;
}

.hero-section::before {
    content: '';
    position: absolute;
    inset: 0;
    background: 
        radial-gradient(ellipse 80% 50% at 50% 0%, rgba(234, 88, 12, 0.15) 0%, transparent 50%),
        radial-gradient(ellipse 60% 40% at 80% 80%, rgba(234, 88, 12, 0.1) 0%, transparent 50%),
        linear-gradient(180deg, #0a0a0a 0%, #0a0a0a 100%);
    z-index: 1;
}

.hero-slider {
    position: absolute;
    inset: 0;
    z-index: 0;
}

.hero-slider .slide {
    position: absolute;
    inset: 0;
    opacity: 0;
    transition: opacity 1.5s ease-in-out;
    z-index: 0;
}

.hero-slider .slide.active {
    opacity: 1;
    z-index: 1;
}

.hero-slider .slide img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    opacity: 0.4;
}

.hero-slider .slide::after {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(180deg, rgba(10,10,10,0.3) 0%, rgba(10,10,10,0.8) 100%);
}

.hero-dots {
    position: absolute;
    bottom: 6rem;
    left: 50%;
    transform: translateX(-50%);
    z-index: 20;
    display: flex;
    gap: 0.75rem;
}

.hero-dot {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.4);
    border: none;
    cursor: pointer;
    transition: all 0.3s ease;
    padding: 0;
}

.hero-dot.active {
    background: #ea580c;
    transform: scale(1.3);
}

.hero-dot:hover {
    background: rgba(255, 255, 255, 0.8);
}

.hero-content {
    position: relative;
    z-index: 10;
}

.hero-title {
    font-size: clamp(3rem, 8vw, 6rem);
    line-height: 1.1;
    background: linear-gradient(135deg, #fafafa 0%, #a3a3a3 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.hero-subtitle {
    font-family: 'Outfit', sans-serif;
    font-size: 1.125rem;
    color: #a3a3a3;
    max-width: 540px;
}

.scroll-indicator {
    position: absolute;
    bottom: 2rem;
    left: 50%;
    transform: translateX(-50%);
    z-index: 10;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 0.5rem;
    color: #525252;
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.1em;
}

.scroll-indicator .line {
    width: 1px;
    height: 60px;
    background: linear-gradient(to bottom, #525252, transparent);
    animation: scrollLine 2s ease-in-out infinite;
}

@keyframes scrollLine {
    0%, 100% { transform: scaleY(1); opacity: 1; }
    50% { transform: scaleY(0.5); opacity: 0.5; }
}
</style>
@endpush

@section('content')
@php
$hero = $sections['hero'] ?? null;
$about = $sections['about'] ?? null;
$cta = $sections['cta'] ?? null;
@endphp

@if($hero)
<section class="hero-section">
    <div class="hero-slider" id="hero-slider">
        @if($hero->getImages()->count() > 0)
            @foreach($hero->getImages() as $index => $image)
                <div class="slide {{ $index === 0 ? 'active' : '' }}" data-index="{{ $index }}">
                    <img src="{{ $image }}" alt="Hero background {{ $index + 1 }}">
                </div>
            @endforeach
        @else
            <div class="slide active" style="background:linear-gradient(135deg,#0a0a0a 0%,#171717 100%)"></div>
        @endif
    </div>

    @if($hero->getImages()->count() > 1)
    <div class="hero-dots" id="hero-dots">
        @foreach($hero->getImages() as $index => $image)
            <button class="hero-dot {{ $index === 0 ? 'active' : '' }}" data-index="{{ $index }}" aria-label="Slide {{ $index + 1 }}"></button>
        @endforeach
    </div>
    @endif
    
    <div class="hero-content max-w-7xl mx-auto px-6 pt-32 pb-20 w-full">
        <div class="max-w-3xl">
            <span class="inline-block px-4 py-2 bg-accent/10 text-accent text-sm font-medium mb-6 border border-accent/20" style="color: #ea580c; border-color: rgba(234,88,12,0.2);">
                Professional Videography
            </span>
            <h1 class="hero-title mb-6">
                {{ $hero->title ?? 'Cinematic Stories That Captivate' }}
            </h1>
            <p class="hero-subtitle mb-10">
                {{ $hero->body ?? 'We transform your moments into compelling visual narratives that resonate with your audience and leave lasting impressions.' }}
            </p>
            <div class="flex flex-wrap gap-4">
                <a href="{{ route('portfolio') }}" class="btn-primary group">
                    <span>View Our Work</span>
                    <svg class="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
                </a>
                <a href="{{ route('contact') }}" class="btn-secondary">
                    Get In Touch
                </a>
            </div>
        </div>
    </div>
    
    <div class="scroll-indicator">
        <span>Scroll</span>
        <div class="line"></div>
    </div>
</section>
@endif

@if($featuredProjects->count() > 0)
<section class="px-6 py-24 bg-dark" style="background-color: #0a0a0a;">
    <div class="max-w-7xl mx-auto">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-end mb-16 gap-6">
            <div class="animate-on-scroll">
                <div class="accent-line"></div>
                <h2 class="section-title">Featured Work</h2>
                <p class="text-gray-500 mt-4 max-w-xl">A curated selection of our most impactful projects</p>
            </div>
            <a href="{{ route('portfolio') }}" class="text-accent font-medium hover:underline flex items-center gap-2 animate-on-scroll delay-200" style="color: #ea580c;">
                View All Projects
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
            </a>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            @foreach($featuredProjects as $project)
                <a href="{{ route('portfolio.show', $project) }}" class="project-card group rounded-none overflow-hidden animate-on-scroll delay-{{ $loop->index * 100 }}">
                    <div class="aspect-video relative overflow-hidden">
                        <img src="{{ $project->coverImageUrl ?? 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=600&q=80' }}" alt="{{ $project->title }}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700">
                        <div class="project-info">
                            <span class="inline-block px-3 py-1 text-xs font-medium rounded-none mb-3 capitalize" style="background: #ea580c; color: white;">
                                {{ $project->category?->name ?? 'Project' }}
                            </span>
                            <h3 class="text-2xl font-display text-white">{{ $project->title }}</h3>
                        </div>
                    </div>
                    <div class="play-button opacity-0 group-hover:opacity-100"></div>
                </a>
            @endforeach
        </div>
    </div>
</section>
@endif

@if($packages->count() > 0)
<section class="px-6 py-24 bg-card" style="background-color: #171717;">
    <div class="max-w-7xl mx-auto">
        <div class="text-center mb-16 animate-on-scroll">
            <div class="accent-line mx-auto"></div>
            <h2 class="section-title">Our Services</h2>
            <p class="text-gray-500 mt-4 max-w-2xl mx-auto">Tailored videography solutions for every need</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            @foreach($packages as $package)
                <div class="service-card animate-on-scroll delay-{{ $loop->index * 100 }}">
                    <div class="w-14 h-14 flex items-center justify-center mb-6" style="background: rgba(234,88,12,0.1);">
                        <svg class="w-7 h-7" style="color: #ea580c;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            @switch($loop->index)
                                @case(0)
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/>
                                    @break
                                @case(1)
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z"/>
                                    @break
                                @case(2)
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"/>
                                    @break
                                @default
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/>
                            @endswitch
                        </svg>
                    </div>
                    <h3 class="text-2xl font-display text-white mb-4">{{ $package->name }}</h3>
                    <p class="text-gray-400 mb-6">{{ $package->description }}</p>
                    @if($package->price)
                        <p class="text-3xl font-display mb-6" style="color: #ea580c;">${{ number_format($package->price, 0) }}</p>
                    @endif
                    @if($package->features)
                        <ul class="space-y-3 mb-8">
                            @foreach($package->features as $feature)
                                <li class="flex items-center gap-3 text-gray-400 text-sm">
                                    <svg class="w-4 h-4 flex-shrink-0" style="color: #ea580c;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                                    {{ $feature }}
                                </li>
                            @endforeach
                        </ul>
                    @endif
                    <a href="{{ route('contact') }}" class="btn-secondary w-full justify-center">Inquire Now</a>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endif

@if($testimonials->count() > 0)
<section class="px-6 py-24 bg-dark" style="background-color: #0a0a0a;">
    <div class="max-w-7xl mx-auto">
        <div class="text-center mb-16 animate-on-scroll">
            <div class="accent-line mx-auto"></div>
            <h2 class="section-title">Client Stories</h2>
            <p class="text-gray-500 mt-4">What our clients say about working with us</p>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            @foreach($testimonials as $testimonial)
                <div class="testimonial-card animate-on-scroll delay-{{ $loop->index * 100 }}">
                    <p class="text-gray-300 text-lg mb-6 leading-relaxed">{{ $testimonial->body }}</p>
                    <div class="flex items-center gap-4">
                        <div class="w-12 h-12 rounded-none flex items-center justify-center text-white font-bold" style="background: linear-gradient(135deg, #ea580c, #dc2626);">
                            {{ strtoupper(substr($testimonial->client_name, 0, 1)) }}
                        </div>
                        <div>
                            <p class="font-semibold text-white">{{ $testimonial->client_name }}</p>
                            @if($testimonial->service_type)
                                <p class="text-gray-500 text-sm">{{ $testimonial->service_type }}</p>
                            @endif
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endif

@if($about)
<section class="px-6 py-24 bg-card" style="background-color: #171717;">
    <div class="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
        <div class="animate-on-scroll">
            <div class="relative">
                <div class="aspect-[4/5] relative overflow-hidden">
                    @if($about->getImageUrl())
                        <img src="{{ $about->getImageUrl() }}" alt="About" class="w-full h-full object-cover">
                    @else
                        <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&q=80" alt="About" class="w-full h-full object-cover">
                    @endif
                </div>
                <div class="absolute -bottom-6 -right-6 w-32 h-32 flex items-center justify-center" style="background: linear-gradient(135deg, #ea580c, #dc2626);">
                    <span class="text-white font-display font-bold text-lg text-center">5+<br>Years</span>
                </div>
            </div>
        </div>
        <div class="animate-on-scroll delay-200">
            <div class="accent-line"></div>
            <h2 class="text-5xl font-display text-white mb-6">{{ $about->title ?? 'About Us' }}</h2>
            <p class="text-gray-400 text-lg mb-8 leading-relaxed">{{ $about->body ?? 'We are a team of passionate videographers dedicated to capturing your most precious moments with cinematic excellence.' }}</p>
            <a href="{{ route('about') }}" class="btn-primary">Learn More About Us</a>
        </div>
    </div>
</section>
@endif

@if($cta)
<section class="px-6 py-24" style="background: linear-gradient(135deg, #ea580c 0%, #dc2626 100%);">
    <div class="max-w-3xl mx-auto text-center animate-on-scroll">
        <h2 class="text-5xl font-display text-white mb-6">{{ $cta->title ?? 'Ready to Create Something Amazing?' }}</h2>
        <p class="text-white/80 text-xl mb-10">{{ $cta->body ?? 'Let\'s discuss your project and bring your vision to life.' }}</p>
        <a href="{{ route('contact') }}" class="inline-flex items-center gap-2 px-8 py-4 bg-white text-gray-900 font-semibold rounded-none hover:bg-gray-100 transition-colors">
            <span>Get in Touch</span>
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
        </a>
    </div>
</section>
@endif

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    var slider = document.getElementById('hero-slider');
    var dotsContainer = document.getElementById('hero-dots');

    if (slider && dotsContainer) {
        var slides = slider.querySelectorAll('.slide');
        var dots = dotsContainer.querySelectorAll('.hero-dot');
        var current = 0;

        function goTo(index) {
            if (index < 0 || index >= slides.length || index === current) return;
            slides[current].classList.remove('active');
            dots[current].classList.remove('active');
            current = index;
            slides[current].classList.add('active');
            dots[current].classList.add('active');
        }

        dots.forEach(function(dot, idx) {
            dot.addEventListener('click', function() {
                goTo(idx);
            });
        });

        if (slides.length > 1) {
            setInterval(function() {
                goTo((current + 1) % slides.length);
            }, 5000);
        }
    }

    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    document.querySelectorAll('.animate-on-scroll').forEach(el => {
        observer.observe(el);
    });
});
</script>
@endpush
@endsection