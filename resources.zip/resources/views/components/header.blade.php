<header class="fixed top-0 left-0 right-0 z-50 bg-dark/90 backdrop-blur-md border-b border-subtle">
    <div class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
        <a href="{{ route('home') }}" class="text-2xl font-display text-white">
            {{ $siteSettings['header']['header_logo_text'] ?? 'FrameFlow' }}
        </a>
        <nav class="hidden md:flex gap-8 items-center">
            <a href="{{ route('home') }}" class="nav-link {{ request()->is('/') ? 'text-white' : '' }}">Home</a>
            <a href="{{ route('portfolio') }}" class="nav-link {{ request()->is('portfolio*') ? 'text-white' : '' }}">Work</a>
            <a href="{{ route('reels') }}" class="nav-link {{ request()->is('reels') ? 'text-white' : '' }}">Reels</a>
            <a href="{{ route('gallery') }}" class="nav-link {{ request()->is('gallery*') ? 'text-white' : '' }}">Gallery</a>
            <a href="{{ route('about') }}" class="nav-link {{ request()->is('about') ? 'text-white' : '' }}">About</a>
            <a href="{{ route('contact') }}" class="btn-primary text-sm py-2 px-5">
                <span>Let's Talk</span>
            </a>
        </nav>
    </div>
</header>