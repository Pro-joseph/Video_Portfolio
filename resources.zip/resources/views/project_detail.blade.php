@extends('layouts.app')

@push('styles')
<style>
.animate-on-scroll {
    opacity: 0;
    transform: translateY(40px);
    transition: opacity 0.8s ease-out, transform 0.8s ease-out;
}

.animate-on-scroll.visible {
    opacity: 1;
    transform: translateY(0);
}

.related-card {
    background: #171717;
    border: 1px solid #262626;
    transition: all 0.4s ease;
}

.related-card:hover {
    transform: translateY(-4px);
    border-color: rgba(234, 88, 12, 0.3);
}
</style>
@endpush

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });
    document.querySelectorAll('.animate-on-scroll').forEach(el => observer.observe(el));
});
</script>
@endpush

@section('title', $project->title . ' - FrameFlow')

@section('content')
<div class="pt-32 pb-20 px-6" style="background: #0a0a0a;">
    <div class="max-w-7xl mx-auto">
        <a href="{{ $project->is_reels ? route('reels') : route('portfolio') }}" class="text-gray-500 hover:text-white transition-colors inline-flex items-center gap-2">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
            Back to {{ $project->is_reels ? 'Reels' : 'Portfolio' }}
        </a>

        <header class="mt-8 mb-16 animate-on-scroll">
            <h1 class="text-5xl font-display text-white mb-4">{{ $project->title }}</h1>
            <p class="text-gray-500 text-xl max-w-2xl">{{ $project->description }}</p>
        </header>

        <section class="space-y-8 animate-on-scroll delay-200">
            @forelse($project->media as $media)
                <div>
                    @if($media->video_url)
                        @php
                            $embedUrl = null;
                            $videoUrl = $media->video_url;
                            
                            if (str_contains($videoUrl, 'youtube.com/shorts/')) {
                                preg_match('/shorts\/([a-zA-Z0-9_-]+)/', $videoUrl, $matches);
                                if (isset($matches[1])) {
                                    $embedUrl = 'https://www.youtube.com/embed/' . $matches[1];
                                }
                            }
                            elseif (str_contains($videoUrl, 'youtube.com') || str_contains($videoUrl, 'youtu.be')) {
                                if (preg_match('/[?&]v=([^&]+)/', $videoUrl, $matches) || preg_match('/youtu\.be\/([a-zA-Z0-9_-]+)/', $videoUrl, $matches)) {
                                    $embedUrl = 'https://www.youtube.com/embed/' . ($matches[1] ?? $matches[2] ?? null);
                                }
                            }
                            elseif (str_contains($videoUrl, 'vimeo.com')) {
                                preg_match('/vimeo\.com\/(\d+)/', $videoUrl, $matches);
                                if (isset($matches[1])) {
                                    $embedUrl = 'https://player.vimeo.com/video/' . $matches[1];
                                }
                            }
                            elseif (str_contains($videoUrl, 'drive.google.com')) {
                                preg_match('/\/d\/([^\/]+)/', $videoUrl, $matches);
                                if (isset($matches[1])) {
                                    $embedUrl = 'https://drive.google.com/file/d/' . $matches[1] . '/preview';
                                }
                            }
                            
                            if (!$embedUrl) {
                                $embedUrl = $videoUrl;
                            }
                        @endphp
                        
                        <div class="aspect-video bg-[#171717] overflow-hidden">
                            <iframe src="{{ $embedUrl }}" class="w-full h-full" frameborder="0" allowfullscreen allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"></iframe>
                        </div>
                    @elseif($media->file_path)
                        <img src="{{ str_starts_with($media->file_path, 'http') ? $media->file_path : asset($media->file_path) }}" class="w-full" alt="{{ $project->title }}">
                    @endif
                </div>
            @empty
                @if($project->cover_image && str_starts_with($project->cover_image, 'http'))
                    <img src="{{ $project->cover_image }}" class="w-full" alt="{{ $project->title }}">
                @else
                    <div class="aspect-video bg-[#171717] flex items-center justify-center">
                        <p class="text-gray-500">No media available.</p>
                    </div>
                @endif
            @endforelse
        </section>

        <div class="mt-16 grid grid-cols-3 gap-8 py-8 border-t" style="border-color: #262626;">
            <div>
                <p class="text-gray-500 text-sm">Category</p>
                <p class="text-white mt-1 font-display">{{ $project->category?->name ?? '-' }}</p>
            </div>
            <div>
                <p class="text-gray-500 text-sm">Date</p>
                <p class="text-white mt-1">{{ $project->created_at->format('M Y') }}</p>
            </div>
            <div>
                <p class="text-gray-500 text-sm">Featured</p>
                <p class="text-white mt-1">{{ $project->is_featured ? 'Yes' : 'No' }}</p>
            </div>
        </div>

        <div class="mt-12 pt-8 border-t" style="border-color: #262626;">
            <h3 class="text-2xl font-display text-white mb-8">{{ $project->is_reels ? 'More Reels' : 'More Projects' }}</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                @foreach(\App\Models\Project::where('id', '!=', $project->id)->where('is_reels', $project->is_reels)->latest()->take(2)->get() as $other)
                    <a href="{{ route('portfolio.show', $other) }}" class="group">
                        <div class="related-card aspect-video overflow-hidden mb-4">
                            <img src="{{ $other->cover_image ?? 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=600&q=80' }}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                        </div>
                        <h4 class="text-white font-display group-hover" style="color: #ea580c;">{{ $other->title }}</h4>
                    </a>
                @endforeach
            </div>
        </div>
    </div>
</div>
@endsection