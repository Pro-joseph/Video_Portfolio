@extends('layouts.app')

@push('styles')
<style>
.animate-on-scroll {
    opacity: 0;
    transform: translateY(40px);
    transition: opacity 0.8s ease-out, transform 0.8s ease-out;
}

.animate-on-scroll.visible {
    opacity: 1;
    transform: translateY(0);
}

.reel-card {
    position: relative;
    overflow: hidden;
    background: #171717;
    transition: transform 0.5s ease;
}

.reel-card::before {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(234, 88, 12, 0.1) 0%, transparent 50%);
    opacity: 0;
    transition: opacity 0.4s ease;
    z-index: 1;
}

.reel-card:hover {
    transform: translateY(-8px);
}

.reel-card:hover::before {
    opacity: 1;
}

.play-button {
    width: 72px;
    height: 72px;
    border-radius: 50%;
    background: rgba(234, 88, 12, 0.9);
    display: flex;
    align-items: center;
    justify-content: center;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    transition: all 0.3s ease;
    z-index: 2;
}

.play-button::after {
    content: '';
    width: 0;
    height: 0;
    border-top: 12px solid transparent;
    border-bottom: 12px solid transparent;
    border-left: 18px solid white;
    margin-left: 4px;
}

.play-button:hover {
    background: #ea580c;
    transform: translate(-50%, -50%) scale(1.1);
}
</style>
@endpush

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });
    document.querySelectorAll('.animate-on-scroll').forEach(el => observer.observe(el));
});
</script>
@endpush

@section('title', 'Reels - FrameFlow')

@section('content')
<div class="pt-32 pb-20 px-6" style="background: #0a0a0a;">
    <div class="max-w-7xl mx-auto">
        <div class="mb-16 animate-on-scroll">
            <div class="accent-line"></div>
            <h1 class="text-5xl font-display text-white mb-4">Reels</h1>
            <p class="text-gray-500 text-xl max-w-2xl">Short-form video highlights from our latest projects.</p>
        </div>

        @if($reels->count() > 0)
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            @foreach($reels as $reel)
                <a href="{{ route('portfolio.show', $reel) }}" class="reel-card group block animate-on-scroll delay-{{ $loop->index * 100 }}">
                    <div class="aspect-[9/16] relative overflow-hidden">
                        @php
                            $thumb = null;
                            $firstMedia = $reel->media->first();
                            
                            if ($reel->cover_image) {
                                $cover = $reel->cover_image;
                                
                                if (str_contains($cover, 'drive.google.com/file/d/')) {
                                    preg_match('/\/d\/([^\/]+)/', $cover, $matches);
                                    if (isset($matches[1])) {
                                        $thumb = 'https://drive.google.com/uc?export=view&id=' . $matches[1];
                                    }
                                }
                                elseif (!str_starts_with($cover, 'http') && !str_starts_with($cover, '/')) {
                                    $thumb = asset('storage/' . $cover);
                                }
                                elseif (filter_var(trim($cover), FILTER_VALIDATE_URL)) {
                                    $thumb = $cover;
                                }
                            }
                            
                            if (!$thumb && $firstMedia && $firstMedia->video_url) {
                                $url = $firstMedia->video_url;
                                
                                if (str_contains($url, 'youtube.com/shorts/')) {
                                    preg_match('/shorts\/([a-zA-Z0-9_-]+)/', $url, $matches);
                                    if (isset($matches[1])) {
                                        $thumb = 'https://img.youtube.com/vi/' . $matches[1] . '/mqdefault.jpg';
                                    }
                                }
                                elseif (preg_match('/[?&]v=([^&]+)/', $url, $matches) || preg_match('/youtu\.be\/([a-zA-Z0-9_-]+)/', $url, $matches)) {
                                    $youtubeId = $matches[1] ?? $matches[2] ?? null;
                                    if ($youtubeId) {
                                        $thumb = 'https://img.youtube.com/vi/' . $youtubeId . '/mqdefault.jpg';
                                    }
                                }
                            }
                            
                            $thumb = $thumb ?: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=400&q=80';
                        @endphp
                        <img src="{{ $thumb }}" alt="{{ $reel->title }}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" onerror="this.src='https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=400&q=80'">
                        <div class="absolute inset-0" style="background: linear-gradient(to top, rgba(10,10,10,0.8) 0%, transparent 50%);"></div>
                        <div class="absolute bottom-0 left-0 right-0 p-4">
                            <h3 class="text-lg font-display text-white">{{ $reel->title }}</h3>
                        </div>
                        <div class="play-button opacity-80 group-hover:opacity-100"></div>
                    </div>
                </a>
            @endforeach
        </div>
        @else
        <div class="text-center py-20">
            <p class="text-gray-500 text-xl">No reels available yet.</p>
            <p class="text-gray-600 mt-2">Check back soon for new content!</p>
        </div>
        @endif
    </div>
</div>
@endsection