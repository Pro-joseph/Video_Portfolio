@extends('layouts.app')

@push('styles')
<style>
.project-card {
    position: relative;
    overflow: hidden;
    background: #171717;
    transition: transform 0.5s ease;
}

.project-card::before {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(234, 88, 12, 0.1) 0%, transparent 50%);
    opacity: 0;
    transition: opacity 0.4s ease;
    z-index: 1;
}

.project-card:hover {
    transform: translateY(-8px);
}

.project-card:hover::before {
    opacity: 1;
}

.project-card .project-info {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 2rem;
    background: linear-gradient(to top, rgba(10, 10, 10, 0.95) 0%, transparent 100%);
    transform: translateY(20px);
    opacity: 0;
    transition: all 0.4s ease;
}

.project-card:hover .project-info {
    transform: translateY(0);
    opacity: 1;
}

.play-button {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    background: rgba(234, 88, 12, 0.9);
    display: flex;
    align-items: center;
    justify-content: center;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    transition: all 0.3s ease;
    z-index: 2;
}

.play-button::after {
    content: '';
    width: 0;
    height: 0;
    border-top: 14px solid transparent;
    border-bottom: 14px solid transparent;
    border-left: 22px solid white;
    margin-left: 6px;
}

.play-button:hover {
    background: #ea580c;
    transform: translate(-50%, -50%) scale(1.1);
}

.filter-btn {
    font-family: 'Outfit', sans-serif;
    font-weight: 500;
    padding: 0.75rem 1.5rem;
    background: transparent;
    border: 1px solid #262626;
    color: #a3a3a3;
    transition: all 0.3s ease;
    cursor: pointer;
}

.filter-btn:hover,
.filter-btn.active {
    background: #ea580c;
    border-color: #ea580c;
    color: white;
}

.animate-on-scroll {
    opacity: 0;
    transform: translateY(40px);
    transition: opacity 0.8s ease-out, transform 0.8s ease-out;
}

.animate-on-scroll.visible {
    opacity: 1;
    transform: translateY(0);
}

.animate-on-scroll.delay-100 { transition-delay: 100ms; }
.animate-on-scroll.delay-200 { transition-delay: 200ms; }
.animate-on-scroll.delay-300 { transition-delay: 300ms; }
</style>
@endpush

@section('title', 'Portfolio - FrameFlow')

@section('content')
<div class="pt-32 pb-20 px-6" style="background: #0a0a0a;">
    <div class="max-w-7xl mx-auto">
        <div class="mb-16 animate-on-scroll">
            <div class="accent-line"></div>
            <h1 class="text-5xl font-display text-white mb-4">Our Work</h1>
            <p class="text-gray-500 text-xl max-w-2xl">A collection of our finest work across various genres and industries.</p>
        </div>

        @if($categories->count() > 0)
        <div class="flex flex-wrap gap-3 mb-12 animate-on-scroll delay-200">
            <button class="filter-btn active" data-category="">All</button>
            @foreach($categories as $cat)
            <button class="filter-btn capitalize" data-category="{{ $cat->slug }}">{{ $cat->name }}</button>
            @endforeach
        </div>
        @endif

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="projects-grid">
            @forelse($projects as $project)
                <a href="{{ route('portfolio.show', $project) }}" class="project-card group animate-on-scroll delay-{{ $loop->index % 3 * 100 }}" data-category="{{ $project->category?->slug ?? '' }}">
                    <div class="aspect-video relative overflow-hidden">
                        <img src="{{ $project->cover_image ? (str_starts_with($project->cover_image, 'http') ? $project->cover_image : asset($project->cover_image)) : 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=600&q=80' }}" alt="{{ $project->title }}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700">
                        <div class="project-info">
                            <span class="inline-block px-3 py-1 text-xs font-medium capitalize" style="background: #ea580c; color: white;">
                                {{ $project->category?->name ?? 'Project' }}
                            </span>
                            <h3 class="text-2xl font-display text-white mt-3">{{ $project->title }}</h3>
                        </div>
                    </div>
                    <div class="play-button opacity-0 group-hover:opacity-100"></div>
                </a>
            @empty
                <div class="col-span-full text-center py-12">
                    <p class="text-gray-500 text-lg">No projects yet.</p>
                </div>
            @endforelse
        </div>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, { threshold: 0.1 });
    
    document.querySelectorAll('.animate-on-scroll').forEach(el => observer.observe(el));

    const filterBtns = document.querySelectorAll('.filter-btn');
    const projectCards = document.querySelectorAll('.project-card');

    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const category = this.dataset.category;

            filterBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');

            projectCards.forEach(card => {
                const cardCategory = card.dataset.category;
                if (category === '' || cardCategory === category) {
                    card.style.display = 'block';
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transform = 'translateY(0)';
                    }, 50);
                } else {
                    card.style.opacity = '0';
                    card.style.transform = 'translateY(20px)';
                    setTimeout(() => {
                        card.style.display = 'none';
                    }, 300);
                }
            });
        });
    });
});
</script>
@endpush
@endsection