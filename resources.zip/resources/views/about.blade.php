@extends('layouts.app')

@push('styles')
<style>
.animate-on-scroll {
    opacity: 0;
    transform: translateY(40px);
    transition: opacity 0.8s ease-out, transform 0.8s ease-out;
}

.animate-on-scroll.visible {
    opacity: 1;
    transform: translateY(0);
}

.stat-card {
    background: #171717;
    border: 1px solid #262626;
    padding: 2rem;
    text-align: center;
    transition: all 0.4s ease;
}

.stat-card:hover {
    border-color: rgba(234, 88, 12, 0.3);
    transform: translateY(-4px);
}

.stat-number {
    font-family: 'DM Serif Display', serif;
    font-size: 3.5rem;
    color: #ea580c;
    line-height: 1;
}

.service-card {
    background: #171717;
    border: 1px solid #262626;
    padding: 2rem;
    transition: all 0.4s ease;
}

.service-card:hover {
    border-color: rgba(234, 88, 12, 0.3);
    transform: translateY(-4px);
}

.testimonial-card {
    background: #171717;
    border: 1px solid #262626;
    padding: 2rem;
    position: relative;
}

.testimonial-card::before {
    content: '"';
    position: absolute;
    top: 1rem;
    left: 1.5rem;
    font-family: 'DM Serif Display', serif;
    font-size: 4rem;
    color: #ea580c;
    opacity: 0.3;
    line-height: 1;
}
</style>
@endpush

@section('title', 'About - FrameFlow')

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });
    document.querySelectorAll('.animate-on-scroll').forEach(el => observer.observe(el));
});
</script>
@endpush

@section('content')
@php
$about = $sections['about'] ?? null;
$stats = $siteSettings ?? [
    'experience' => '15+',
    'projects' => '200+', 
    'clients' => '150+',
    'awards' => '50+'
];
@endphp

<div class="pt-32 pb-20 px-6" style="background: #0a0a0a;">
    <div class="max-w-7xl mx-auto">
        @if($about)
        <div class="grid grid-cols-1 md:grid-cols-2 gap-16 mb-24 items-center">
            <div class="animate-on-scroll">
                <div class="relative">
                    <div class="aspect-[4/5] relative overflow-hidden">
                        @if($about && $about->getImageUrl())
                        <img src="{{ $about->getImageUrl() }}" alt="About Us" class="w-full h-full object-cover">
                        @else
                        <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&q=80" alt="About Us" class="w-full h-full object-cover">
                        @endif
                    </div>
                    <div class="absolute -bottom-6 -right-6 w-28 h-28 flex items-center justify-center" style="background: linear-gradient(135deg, #ea580c, #dc2626);">
                        <span class="text-white font-display font-bold text-lg text-center">5+<br>Years</span>
                    </div>
                </div>
            </div>
            <div class="animate-on-scroll delay-200">
                @if($about->title)
                <div class="accent-line"></div>
                <h1 class="text-5xl font-display text-white mb-6">{{ $about->title }}</h1>
                @endif
                @if($about->body)
                <p class="text-gray-400 text-lg mb-8 leading-relaxed">{{ $about->body }}</p>
                @endif
                <a href="{{ route('contact') }}" class="btn-primary">Work With Us</a>
            </div>
        </div>
        @endif

        @if(count($stats) > 0)
        <section class="py-16 mb-20" style="background: linear-gradient(135deg, #171717 0%, #0a0a0a 100%); border: 1px solid #262626;">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                @if(isset($stats['experience']))
                <div class="stat-card animate-on-scroll">
                    <p class="stat-number">{{ $stats['experience'] }}</p>
                    <p class="text-gray-500 mt-2">Years Experience</p>
                </div>
                @endif
                @if(isset($stats['projects']))
                <div class="stat-card animate-on-scroll delay-100">
                    <p class="stat-number">{{ $stats['projects'] }}</p>
                    <p class="text-gray-500 mt-2">Projects</p>
                </div>
                @endif
                @if(isset($stats['clients']))
                <div class="stat-card animate-on-scroll delay-200">
                    <p class="stat-number">{{ $stats['clients'] }}</p>
                    <p class="text-gray-500 mt-2">Clients</p>
                </div>
                @endif
                @if(isset($stats['awards']))
                <div class="stat-card animate-on-scroll delay-300">
                    <p class="stat-number">{{ $stats['awards'] }}</p>
                    <p class="text-gray-500 mt-2">Awards</p>
                </div>
                @endif
            </div>
        </section>
        @endif

        @if($packages->count() > 0)
        <section class="mb-20">
            <div class="text-center mb-12 animate-on-scroll">
                <div class="accent-line mx-auto"></div>
                <h2 class="text-4xl font-display text-white mb-4">Our Services</h2>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                @foreach($packages as $package)
                    <div class="service-card animate-on-scroll delay-{{ $loop->index * 100 }}">
                        <h3 class="text-xl font-display text-white mb-4">{{ $package->name }}</h3>
                        <p class="text-gray-400 mb-4">{{ $package->description }}</p>
                        @if($package->price)
                            <p class="text-2xl font-display" style="color: #ea580c;">${{ number_format($package->price, 0) }}</p>
                        @endif
                    </div>
                @endforeach
            </div>
        </section>
        @endif

        @if($testimonials->count() > 0)
        <section>
            <div class="text-center mb-12 animate-on-scroll">
                <div class="accent-line mx-auto"></div>
                <h2 class="text-4xl font-display text-white mb-4">What Clients Say</h2>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                @foreach($testimonials as $t)
                    <div class="testimonial-card animate-on-scroll delay-{{ $loop->index * 100 }}">
                        <p class="text-gray-300 mb-6">"{{ $t->body }}"</p>
                        <div class="flex items-center gap-4">
                            <div class="w-10 h-10 flex items-center justify-center text-white font-bold" style="background: linear-gradient(135deg, #ea580c, #dc2626);">
                                {{ strtoupper(substr($t->client_name, 0, 1)) }}
                            </div>
                            <div>
                                <p class="font-display text-white">{{ $t->client_name }}</p>
                                @if($t->service_type)
                                    <p class="text-gray-500 text-sm">{{ $t->service_type }}</p>
                                @endif
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </section>
        @endif
    </div>
</div>
@endsection